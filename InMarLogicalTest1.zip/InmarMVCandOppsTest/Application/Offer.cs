﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InmarMVCandOppsTest.Application
{
    public class Offer
    {
        public string OfferName { get; set; }
        public List<Product> products { get; set; }

        public Offer(string OfferName ,List<Product> products)
        {
            this.OfferName = OfferName;
            this.products = products;
        }

    }
}