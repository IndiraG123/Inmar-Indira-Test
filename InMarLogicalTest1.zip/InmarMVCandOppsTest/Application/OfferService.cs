﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InmarMVCandOppsTest.Application
{
    public class OfferService
    {
        private List<Product> Inventory;

       
        private void AddProducts()
        {
            Inventory.Add(new Product(ProductName = "P1", Price = 1000, Description = "P1 Desc"))

              
            
            
        }
    }
}