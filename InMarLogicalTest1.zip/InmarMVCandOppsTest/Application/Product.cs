﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InmarMVCandOppsTest.Application
{
    public class Product
    {
        private string productName { get; set; }


        public string ProductName
        {
            get { return productName; }
            set { productName = value; }
        }

        public decimal Price { get; set; }
        public string Description { get; set; }

        public Product(string ProductName, decimal Price, string Description)
        {
            this.ProductName = ProductName;
            this.Price = Price;
            this.Description = Description;
        }

    }
}